﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;


namespace TCPServer
{
    public partial class Form1 : Form
    {
        private delegate void UpdateStatusCallback(string strMessage);
        private TcpListener tcpListener;
        private Thread listenThread;
        int intje;
        byte[] message2 = new byte[4096];
        int bytesRead2;
        int actie;

        string html1 = "<html>"
                + "<head><title>C# server voor Robot</title></head>"
            //+ "<body bgcolor=#8463ff><p><br></br><center><h1><font color='blue'>C# server voor  Robot</font></center></p>"
                + "<body><p><br></br><center><h1><font color='blue'>C# server voor  Robot</font></center></p>"
                + "<br></br>"
                + "<p><center><form method=get action=v ><input type=Submit value=' Vooruit ' style='font-size:20px;font-weight:500'></form></center></p>"
                + "<table><table width='30%' align='center'>"
                + "<tr><middle>"

                      + "<td width=25%><left><form method=get action=l><input type=Submit value='  Links   '  style='font-size:20px;font-weight:500'></form></left></td>"
                      + "<td width=25%><center><form method=get action=s><input type=Submit value='   Stop    '  style='font-size:20px;font-weight:500'></form></center></td>"
                      + "<td width=25%><right><form method=get action=r><input type=Submit value=' Rechts  '  style='font-size:20px;font-weight:500'></form></right></td>"

                + "</tr>"
                + "</table>"

                + "<p><center><form method=get action=a><input type=Submit value='Achteruit'  style='font-size:20px;font-weight:500'></form></center></p>"
                + "<br></br>"
                + "<center><img src='C:/Users/sony/Desktop/WFF_Generic_HID_Demo_3/WFF Generic HID Demo 3/WFF Generic HID Demo 3/Resources/background.jpg' alt='太平洋网络学院' align=top border=1></center>"
                + "<center><br></br><a href='http://www.google.com' runat='server' style='font-size:small;' id='hrefId'><font color='#800000'>TestLink</font></a></center>"
                + "</body>"



                + "</html>";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            //  this.tcpListener = new TcpListener(IPAddress.Any, 81);
            this.tcpListener = new TcpListener(IPAddress.Parse("192.168.0.195"), 2000);

            this.listenThread = new Thread(new ThreadStart(ListenForClients));
            this.listenThread.Start();
            bytesRead2 = 0;
            intje = 0;
            actie = -1;
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            fromtextBox.AppendText("Start listening...\r\n");
            // Parse the server's IP address out of the TextBox
            IPAddress ipAddr = IPAddress.Parse("192.168.0.195");
            // Create a new instance of the ChatServer object
            Server mainServer = new Server(ipAddr);
            // Hook the StatusChanged event handler to mainServer_StatusChanged
            Server.StatusChanged += new StatusChangedEventHandler(mainServer_StatusChanged);
            // Start listening for connections
            mainServer.StartListening();
           
            // Show that we started to listen for connections
            fromtextBox.AppendText("Monitoring for connections...\r\n");
        }

        public void mainServer_StatusChanged(object sender, StatusChangedEventArgs e)
        {
            // Call the method that updates the form
            this.Invoke(new UpdateStatusCallback(this.UpdateStatus), new object[] { e.EventMessage });
        }

        private void UpdateStatus(string strMessage)
        {
            // Updates the log with the message
            fromtextBox.AppendText(strMessage + "\r\n");
        }



        private void forwardButton_Click(object sender, EventArgs e)
        {
            Server.SendMessage("Server says:F");
        }

       

        private void backwardButton_Click(object sender, EventArgs e)
        {
            Server.SendMessage("Server says:B");
        }

        private void leftButton_Click(object sender, EventArgs e)
        {
            Server.SendMessage("Server says:L");
        }

        private void rightButton_Click(object sender, EventArgs e)
        {
            Server.SendMessage("Server says:R");
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            Server.SendMessage("Server says:S");
        }





        private void ListenForClients()
        {
            this.tcpListener.Start();

            while (true)
            {
                //blocks until a client has connected to the server
                TcpClient client = this.tcpListener.AcceptTcpClient();
                intje += 100;
                //create a thread to handle communication
                //with connected client
                Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
                clientThread.Start(client);

            }
        }



        private void HandleClientComm(object client)
        {
            TcpClient tcpClient = (TcpClient)client;
            NetworkStream clientStream = tcpClient.GetStream();
            ASCIIEncoding encoder = new ASCIIEncoding();
            byte[] buffer = new byte[4096];



            byte[] message = new byte[4096];
            int bytesRead;
            int i, j;
            while (true)
            {
                bytesRead = 0;
                intje++;
                try
                {
                    //blocks until a client sends a message
                    bytesRead = clientStream.Read(message, 0, 4096);
                    if (bytesRead > 2)
                    {
                        message2 = message;
                        bytesRead2 = bytesRead;
                        //haal de get yut de http request
                        actie = -1;
                        for (i = 0; i < bytesRead2 - 2; i++)
                        {
                            if (message[i] == 'G' && message[i + 1] == 'E' && message[i + 2] == 'T')
                            {
                                actie = i;
                                break;
                            }

                        }

                        if (actie != -1)
                        {
                            i = actie + 5;
                            if (message[i] == 'v') Server.SendMessage("Server says:F");
                            if (message[i] == 'a') Server.SendMessage("Server says:B");
                            if (message[i] == 'l') Server.SendMessage("Server says:L");
                            if (message[i] == 'r') Server.SendMessage("Server says:R");
                            if (message[i] == 's') Server.SendMessage("Server says:S");
                        }



                        //antwoord
                        buffer = encoder.GetBytes(html1);
                        clientStream.Write(buffer, 0, buffer.Length);
                        clientStream.Flush();
                        break;
                    }
                }
                catch
                {
                    //a socket error has occured
                    break;
                }

                if (bytesRead == 0)
                {
                    //the client has disconnected from the server
                    break;
                }


            }

            tcpClient.Close();
        }

      
       

    }
}
