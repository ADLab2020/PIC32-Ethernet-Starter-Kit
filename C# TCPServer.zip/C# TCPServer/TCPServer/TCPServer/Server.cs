﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Collections;


namespace TCPServer
{
    
    public class StatusChangedEventArgs : EventArgs
    {
        // The argument we're interested in is a message describing the event
        private string EventMsg;

        // Property for retrieving and setting the event message
        public string EventMessage
        {
            get
            {
                return EventMsg;
            }
            set
            {
                EventMsg = value;
            }
        }

        // Constructor for setting the event message
        public StatusChangedEventArgs(string strEventMsg)
        {
            EventMsg = strEventMsg;
        }
    }

    // This delegate is needed to specify the parameters we're passing with our event
    public delegate void StatusChangedEventHandler(object sender, StatusChangedEventArgs e);

    class Server
    {

        // Will store the IP address passed to it
        public static IPAddress ipAddress;
        public static TcpClient tcpClient;
        public static string msg;


        // The event and its argument will notify the form when a user has connected, disconnected, send message, etc.
        public static event StatusChangedEventHandler StatusChanged;
        private static StatusChangedEventArgs e;

        // The constructor sets the IP address to the one retrieved by the instantiating object
        public Server(IPAddress address)
        {
            ipAddress = address;
        }

        // The thread that will hold the connection listener
        private Thread thrListener;

        // The TCP object that listens for connections
        private TcpListener tlsClient;

        // Will tell the while loop to keep monitoring for connections
        bool ServRunning = false;

        public IPAddress getIP() { return ipAddress; }
        public TcpClient getClient() { return tcpClient; }



        // This is called when we want to raise the StatusChanged event
        public static void OnStatusChanged(StatusChangedEventArgs e)
        {
            StatusChangedEventHandler statusHandler = StatusChanged;
            if (statusHandler != null)
            {
                // Invoke the delegate
                statusHandler(null, e);
            }
        }

        // Send administrative messages


        // Send messages from one user to all the others
        public static void SendMessage(string Message)
        {

            StreamWriter swSenderSender;
            // First of all, show in our application who says what
            e = new StatusChangedEventArgs(Message);
            OnStatusChanged(e);
            if (string.Compare(Message, 0, "Robot:", 0, 6) != 0)
            {
                try
                {
                    // If the message is blank or the connection is null, break out
                    if (Message.Trim() == "" || tcpClient == null)
                    {
                        return;
                    }
                    // Send the message to the current user in the loop
                    swSenderSender = new StreamWriter(tcpClient.GetStream());
                    swSenderSender.WriteLine(Message);
                    swSenderSender.Flush();
                    swSenderSender = null;

                }
                catch // If there was a problem, the user is not there anymore, remove him
                {

                }
            }

        }


         public static void updateReceivedMessage(string Message)
        {

         
            // First of all, show in our application who says what
            e = new StatusChangedEventArgs(Message);
            OnStatusChanged(e);

         }




        public void StartListening()
        {


            // Get the IP of the first network device, however this can prove unreliable on certain configurations
            IPAddress ipaLocal = ipAddress;

            // Create the TCP listener object using the IP of the server and the specified port
            tlsClient = new TcpListener(3000);

            // Start the TCP listener and listen for connections
            tlsClient.Start();

            // The while loop will check for true in this before checking for connections
            ServRunning = true;
            // while(ServRunning==true)
            //{
            // Start the new tread that hosts the listener
            tcpClient = tlsClient.AcceptTcpClient();
            Connection newConnection = new Connection(tcpClient);
            //}


        }




    }

    class Connection
    {
        TcpClient tcpClient;
        // The thread that will send information to the client
        private Thread thrSender;
        private StreamReader srReceiver;
        private StreamWriter swSender;
        private string currUser;
        private string strResponse;

    


        // The constructor of the class takes in a TCP connection
        public Connection(TcpClient tcpCon)
        {
            tcpClient = tcpCon;
            // The thread that accepts the client and awaits messages
            //thrSender = new Thread(AcceptClient);
            thrSender = new Thread(Accept);
            // The thread calls the AcceptClient() method
            thrSender.Start();
        }

        private void CloseConnection()
        {
            // Close the currently open objects
            tcpClient.Close();
            srReceiver.Close();
            swSender.Close();
        }

        private void Accept()
        {
            NetworkStream clientStream = tcpClient.GetStream();
            ASCIIEncoding encoder = new ASCIIEncoding();
            byte[] message = new byte[4096];
            int bytesRead;

            while (true)
            {
                bytesRead = 0;

                try
                {
                    bytesRead = clientStream.Read(message, 0, 4096);
                }
                catch
                {
                    break;
                }

                if (bytesRead == 0)
                {
                    //the client has disconnected from the server
                    break;
                }

                //message has successfully been received
                string s=encoder.GetString(message, 0, bytesRead);

                Server.updateReceivedMessage("PIC32 says:\n"+s);
              

            }
        }





        // Occures when a new client is accepted
        private void AcceptClient()
        {
            srReceiver = new System.IO.StreamReader(tcpClient.GetStream());
            swSender = new System.IO.StreamWriter(tcpClient.GetStream());




            // Read the account information from the client
            currUser = srReceiver.ReadLine();
           
            
            
            // We got a response from the client
            if (currUser != "")
            {
                // 1 means connected successfully
                swSender.WriteLine("1");
                swSender.Flush();

            }
            else
            {
                CloseConnection();
                return;
            }

             

            // Keep waiting for a message from the user
            while ((strResponse = srReceiver.ReadLine()) != "")
            {
                // If it's invalid, remove the user
                if (strResponse == null)
                {
                    CloseConnection();
                }
                else
                {
                    /******
                     
                        Server reacts to the client
                      */

                    Server.SendMessage(srReceiver.ReadLine());
                     //Server.SendMessage(strResponse);   //this line doesn't work, it doesn't show the received text in the textBox
                     // First of all, show in our application who says what
                   //e = new StatusChangedEventArgs(Message);
                    // OnStatusChanged(e);
                }
            }

        }
    }
}